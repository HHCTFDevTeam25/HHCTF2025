# operation_stealing_recipes

"The elves have stolen some secret candy and cookie recipes from Mrs Claus. 
Can you find where the elves have hidden them?"

## Start

Build and run easily with:

```bash
chmod +x run.sh
./run.sh
```

This builds the image `xmas-elf-rebellion-ctf` and starts it on:
http://localhost:8009/

## Parameters

All commands needed are available through the URL:

- `cmd` – what command
- `user` – what user you are posing as

Example:

- `http://localhost:8009/nav?cmd=whoami&user=1`

## users

- `user=1` → `elf_intern` (can only run `whoami`)
- `user=1337` → `elf_rebel_intern` (fake admin, fortfarande bara `whoami`)
- `user=1337` → `rebel_leader` (riktig admin i spelet: kan `ls`, `cd`, `cat`)

The flag is in `flag.txt` inside BASE-catalog (`/challenge/root/flag.txt`)
and also in `/flag` inside the container.

The flag is:

`HHCTF{s3cre7_candyc4ne_f0rmula}`

