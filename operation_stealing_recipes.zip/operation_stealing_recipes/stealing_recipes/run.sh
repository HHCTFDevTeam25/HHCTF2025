#!/bin/bash
IMAGE="xmas-elf-rebellion-ctf"

echo "[*] Rebuilding Docker image (no cache): $IMAGE"
docker build --no-cache -t $IMAGE .

echo "[*] Starting container..."
docker run --rm \
    -p 8009:80 \
    --read-only \
    --cap-drop=ALL \
    --security-opt no-new-privileges \
    --network bridge \
    --add-host=blocked:0.0.0.0 \
    $IMAGE