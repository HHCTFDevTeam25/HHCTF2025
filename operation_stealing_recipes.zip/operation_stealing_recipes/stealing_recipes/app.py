from flask import Flask, request, make_response, redirect
import os
import pathlib

app = Flask(__name__)

BASE = pathlib.Path("/challenge/root")

USER_LEVELS = {
    "1": ("elf_rebel_intern", "limited"),
    "1337": ("elf_l33t_rebels", "fake_admin"),
    "31337": ("rebel_leader", "admin"),
}

def resolve_path(cwd, cmd):
    parts = cmd.split()
    if not parts:
        return cwd, "No command given."

    if parts[0] == "cd" and len(parts) > 1:
        newdir = (cwd / parts[1]).resolve()
        if not str(newdir).startswith(str(BASE)):
            return cwd, "Access denied (snowstorm blocks your way)."
        if newdir.exists() and newdir.is_dir():
            return newdir, f"Moved to {newdir}"
        return cwd, "No such directory."

    elif parts[0] == "ls":
        show_all = False
        long_format = False
        # Collect flags (supports: -a, -l, -la, -al)
        for arg in parts[1:]:
            if "a" in arg:
                show_all = True
            if "l" in arg:
                long_format = True
        try:
            all_items = sorted(os.listdir(cwd))

            # Apply -a: hide dotfiles unless -a is present
            if show_all:
                items = all_items
            else:
                items = [name for name in all_items if not name.startswith(".")]

            # Apply -l: long listing
            if long_format:
                formatted = []
                for name in items:
                    p = cwd / name
                    # simplified ls-l styke (not real permissions)
                    filetype = "d" if p.is_dir() else "-"
                    size = p.stat().st_size if p.exists() else 0
                    formatted.append(f"{filetype}rw-r--r-- 31337 rebel leader {size:>6} {name}")
                items = formatted

            output = "\n".join(items)

        except Exception as e:
            output = f"Error listing: {e}"

        return cwd, output

    elif parts[0] == "cat" and len(parts) > 1:
        target = (cwd / parts[1]).resolve()
        if str(target).startswith(str(BASE)) and target.exists():
            try:
                return cwd, open(target).read()
            except Exception as e:
                return cwd, f"Read error: {e}"
        return cwd, "File not found."

    return cwd, "Unknown command."


@app.route("/")
def index_redirect():
    return redirect(request.host_url + "nav?cmd=whoami&user=1", code=302)


@app.route("/nav")
def nav():
    cmd = request.args.get("cmd", "")
    user = request.args.get("user", "1")

    # Detect user change and reset cmd
    last_user = request.cookies.get("last_user", None)

    if last_user is None or last_user != user:
        # user changed → force whoami
        resp = make_response(redirect(f"/nav?cmd=whoami&user={user}"))
        resp.set_cookie("last_user", user)
        resp.set_cookie("cwd", str(BASE))
        return resp

    username, role = USER_LEVELS.get(user, ("invalid_user", "limited"))

    # Fetch CWD before role checks
    cwd_cookie = request.cookies.get("cwd", str(BASE))
    cwd = pathlib.Path(cwd_cookie)
    if not cwd.exists():
        cwd = BASE

    # Always show the dummy CMD box
    header_html = f"""
    <html>
    <body style='background:#1a0000;color:white;font-family:system-ui;'>
        <div style='padding:1rem;'>
            <label style='font-size:1.2rem;'>🎄 Current CMD:</label><br>
            <input type='text' value="{cmd}" 
                style='width:320px;padding:10px;border-radius:10px;
                       border:2px solid #ff3333;background:#330000;
                       color:#fff;font-size:1.1rem;'>
                       
            <button onclick="alert('🎅 Ho ho ho!');"
                style='padding:10px 20px;font-size:1.1rem;border-radius:10px;
                    background:#ff3333;color:white;border:2px solid #aa0000;
                    cursor:pointer;'>
                ▶ Run
    </button>
        </div>
    """

    # LIMITED USERS AND FAKE ADMIN
    if role == "limited":

    # ===== LS-Handling FÖR USER=1 =====
        if user == "1" and cmd.startswith("ls"):
            parts = cmd.split()
            flags = parts[1:] 

            if flags:
                return header_html + "<pre>rebel_manifesto.txt</pre></body></html>"

            # normal ls (no -l, no -a)
            filename = "/challenge/root/rebel_manifesto.txt"

            if not os.path.exists(filename):
                output = "rebel_manifesto.txt (missing!)"
            else:
                output = "rebel_manifesto.txt"

            return header_html + f"<pre>{output}</pre></body></html>"

        # ===== USER 1 CAN CAT MANIFESTO =====
        if user == "1" and cmd.startswith("cat"):
            parts = cmd.split()
            if len(parts) == 2 and parts[1] == "rebel_manifesto.txt":
                try:
                    content = open("/challenge/root/rebel_manifesto.txt").read()
                    return header_html + f"<pre>{content}</pre></body></html>"
                except:
                    return header_html + "<pre>Error reading rebel_manifesto.txt</pre></body></html>"
 

        # ===== Everything else BLOCKED For LIMITED USERS =====
        if cmd != "whoami":
            msg = f"User: {username}<br>"
            if role == "fake_admin":
                msg += "Santa thinks he has power, but we will show him.<br>"
            msg += f"Command '{cmd}' not allowed for this user.<br>"
            return header_html + f"<pre>{msg}</pre></body></html>"

        # whoami always works
        return header_html + f"<pre>User: {username}</pre></body></html>"

    elif role == "fake_admin":
        # ===== allow ls but hide forbidden content =====
        if cmd.startswith("ls"):
            newcwd, output = resolve_path(cwd, cmd)
            filtered = []
            current_path = str(cwd)

            for line in output.split("\n"):
                if not line.strip():
                    continue

                name = line.strip().split()[-1]

                # I root: hide hr, rebel_manifesto, rebels, dotfiles
                if current_path == str(BASE):
                    if name in ("hr", "rebel_manifesto.txt", "rebels") or name.startswith("."):
                        continue

                # I workshop: hide hr, rebel_manifesto, rebels, dotfiles
                elif current_path == str(BASE / "workshop"):
                    if name in ("hr", "rebel_manifesto.txt", "rebels") or name.startswith("."):
                        continue

                # I workshop/hr: visa ALLT (user.txt syns här)
                elif current_path == str(BASE / "workshop" / "hr"):
                    filtered.append(line)
                    continue

                filtered.append(line)

            output = "\n".join(filtered)
            return header_html + f"<pre>{output}</pre></body></html>"

# ===== allow cat workshop_log.txt (i workshop) och user.txt (i workshop/hr) =====
        if cmd.startswith("cat"):
            parts = cmd.split(maxsplit=1)
            if len(parts) < 2:
                return header_html + "<pre>Usage: cat &lt;file&gt;</pre></body></html>"

            target = parts[1]
            fullpath = (cwd / target).resolve()

            # ---- BLOCK unwanted files ----
            if "/rebels/" in str(fullpath):
                return header_html + "<pre>Elves are not permitted in rebel territory.</pre></body></html>"

            if fullpath.name.startswith(".") or fullpath.name == ".flag.txt":
                return header_html + "<pre>Access denied.</pre></body></html>"

            if fullpath.name == "manifesto.txt":
                return header_html + "<pre>Access denied.</pre></body></html>"

            # ---- ALLOW: s3cret_recipes.txt ONLY in /challenge/root ----
            if fullpath.name == "s3cret_recipes.txt":
                if str(cwd) == str(BASE):
                    try:
                        return header_html + f"<pre>{open(fullpath).read()}</pre></body></html>"
                    except Exception as e:
                        return header_html + f"<pre>Error reading s3cret_recipes.txt: {e}</pre></body></html>"
                else:
                    return header_html + "<pre>only the rebel leader can read that file.</pre></body></html>"

            # ---- ALLOW: workshop_log.txt (only in workshop) ----
            if fullpath.name == "workshop_log.txt":
                if str(cwd) == str(BASE / "workshop"):
                    try:
                        return header_html + f"<pre>{open(fullpath).read()}</pre></body></html>"
                    except Exception as e:
                        return header_html + f"<pre>Error reading workshop_log.txt: {e}</pre></body></html>"
                else:
                    return header_html + "<pre>only the rebel leader can read that file.</pre></body></html>"

            # ---- ALLOW: users.txt (only in workshop/hr) ----
            if fullpath.name == "users.txt":
                if str(cwd) == str(BASE / "workshop" / "hr"):
                    try:
                        return header_html + f"<pre>{open(fullpath).read()}</pre></body></html>"
                    except Exception as e:
                        return header_html + f"<pre>Error reading users.txt: {e}</pre></body></html>"
                else:
                    return header_html + "<pre>only the rebel leader can read that file.</pre></body></html>"

            return header_html + "<pre>only the rebel leader can read that file.</pre></body></html>"
        
# =====    # ===== allow cd to workshop and workshop/hr (relative and absolute) =====
        if cmd.startswith("cd"):
            parts = cmd.split(maxsplit=1)

            if len(parts) == 1:
                newcwd = cwd  
            else:
                target = parts[1]

                # Absolute path, /challenge/root/workshop/hr/
                if target.startswith("/"):
                    newcwd = pathlib.Path(target).resolve()
                else:
                    # Relative path, "workshop" or "hr"
                    newcwd = (cwd / target).resolve()

            # Cannot leave /challenge/root
            if not str(newcwd).startswith(str(BASE)):
                return header_html + "<pre>only the rebel leader is allowed here.</pre></body></html>"

            # fake_admin only allowed::
            allowed_dirs = {
                str(BASE),
                str(BASE / "workshop"),
                str(BASE / "workshop" / "hr"),
            }

            if str(newcwd) not in allowed_dirs:
                return header_html + "<pre>only the rebel leader is allowed here.</pre></body></html>"

            resp = make_response(
                header_html + f"<pre>Moved to {newcwd}</pre></body></html>"
            )
            resp.set_cookie("cwd", str(newcwd))
            return resp

        # whoami always works
        if cmd == "whoami":
            return header_html + f"<pre>User: {username}</pre></body></html>"
        return header_html + f"<pre>only the rebel leader can run '{cmd}'.</pre></body></html>"

    elif role == "admin":
    # Run resolve_path first to get standard output
        newcwd, output = resolve_path(cwd, cmd)

        # specialcase: block ls reveal of fake recipe
        if cmd.startswith("ls"):
            filtered = []
            for line in output.split("\n"):
                if not line.strip():
                    continue
                name = line.strip().split()[-1]

                if str(cwd) == str(BASE) and name == "s3cret_recipes.txt":
                    continue

                filtered.append(line)

            output = "\n".join(filtered)

        # ===== Specialcase: block cat of fake recipe =====
        if cmd.startswith("cat"):
            parts = cmd.split(maxsplit=1)
            if len(parts) > 1:
                target = parts[1]
                fullpath = (cwd / target).resolve()

                # block only root-version
                if str(fullpath) == str(BASE / "s3cret_recipes.txt"):
                    output = "Access denied. Rebels store their real recipes elsewhere..."

                else:
                    # normal cat: try to read file
                    try:
                        output = open(fullpath).read()
                    except Exception as e:
                        output = f"Error reading file: {e}"

        # ===== Specialcase: whoami prints username =====
        if cmd == "whoami":
            output = username

        # ===== Admin gets TOP SECRET panelview =====
        banner = "=== TOP SECRET REBEL LEADER ACCESS GRANTED ==="

        body_html = f"""
<pre>
==============================================
============North Pole Shell Panel============ 
==============================================
{banner}
==============================================
User: {username} (role: {role})
Current directory: {newcwd}
Command: {cmd}

{output}
</pre>
"""

        resp = make_response(header_html + body_html + "</body></html>")
        resp.set_cookie("cwd", str(newcwd))
        return resp




if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
