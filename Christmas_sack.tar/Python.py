from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
import os
import hashlib
import binascii

PASSWORD = b"M4y1Pr3tty" + b"P13a5e" + b"H4v3Flag"   
REAL_FLAG = b"HHCTF{ATL35T_IS_N0T_C04L_4G41N}"  


iterations = 100_000
salt = os.urandom(8)   # 8-byte salt
nonce = os.urandom(12) # 12-byte nonce

# Derive key
kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations)
key = kdf.derive(PASSWORD)

# Encrypt
aesgcm = AESGCM(key)
ciphertext = aesgcm.encrypt(nonce, REAL_FLAG, None)

blob = b"RFGB" + salt + nonce + ciphertext

# Print encrypted blob for C file
print("Paste this encrypted_blob[] into .c file ")
print("static const unsigned char encrypted_blob[] = {")
print(", ".join(str(b) for b in blob) + ",")
print("};")
print()
print("// blob length:", len(blob))
print("// iterations:", iterations)
print()

# Generate 50 fake hex strings that decode to "coal"
coal_hex = "636f616c"  # hex encoding of 'coal'
fake_hex = [coal_hex for _ in range(50)]

print("Paste these fake_hex into challenge.c")
print("static const char *fake_hex[50] = {")
for h in fake_hex:
    print('    "' + h + '",')
print("};")
print()

# Print salt/nonce info for fun
print("// Salt (hex):", salt.hex())
print("// Nonce (hex):", nonce.hex())
print("// Ciphertext (hex):", ciphertext.hex())
print("// Password (plaintext):", PASSWORD.decode())
