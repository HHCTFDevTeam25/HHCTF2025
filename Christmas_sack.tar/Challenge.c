#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#include <openssl/evp.h>
#include <openssl/err.h>

#define ITERATIONS 100000 


// Posted blob from python script
static const unsigned char encrypted_blob[] = {
82, 70, 71, 66, 209, 148, 222, 84, 46, 3, 173, 171, 188, 84, 189, 155, 231, 133, 122, 115, 140, 1, 13, 90, 139, 241, 224, 88, 82, 199, 124, 62, 83, 250, 83, 247, 176, 170, 139, 66, 195, 12, 59, 92, 141, 110, 142, 49, 69, 156, 255, 118, 202, 178, 208, 159, 24, 71, 145, 139, 218, 150, 88, 235, 111, 198, 228, 25, 79, 40, 68,
};
static const size_t encrypted_blob_len = sizeof(encrypted_blob);


//Hex-value "coal" - fake hex array
static const char *fake_hex[50] = {
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c",
    "636f616c","636f616c","636f616c","636f616c","636f616c"
};


// REAL password (visible in ghidra)
static const char p1[] __attribute__((used)) = "M4y1Pr3tty";
static const char p2[] __attribute__((used)) = "P13a5e";
static const char p3[] __attribute__((used)) = "H4v3Flag";

static volatile unsigned char keep_val = 0;

static void touch_password_fragments(void) {
    keep_val ^= (unsigned char)p1[0];
    keep_val ^= (unsigned char)p2[0];
    keep_val ^= (unsigned char)p3[0];
}

// Parse the blob format: RFGB salt, prevents brute force. nonce, needed for AES-GCM
int parse_blob(const unsigned char *blob, size_t blob_len,
               const unsigned char **salt, size_t *salt_len,
               const unsigned char **nonce, size_t *nonce_len,
               const unsigned char **ciphertext, size_t *ciphertext_len)
{
    if (blob_len < 4 + 8 + 12) return -1;
    if (!(blob[0] == 'R' && blob[1] == 'F' && blob[2] == 'G' && blob[3] == 'B')) return -2;

    size_t off = 4;
    *salt = blob + off; *salt_len = 8; off += 8;
    *nonce = blob + off; *nonce_len = 12; off += 12;
    *ciphertext = blob + off; *ciphertext_len = blob_len - off;
    return 0;
}

// Derive key with PBKDF2-HMAC-SHA256 - slow down bruteforce
int derive_key_pbkdf2(const unsigned char *password, size_t password_len,
                      const unsigned char *salt, size_t salt_len,
                      int iterations, unsigned char *out_key, size_t key_len)
{
    if (!PKCS5_PBKDF2_HMAC((const char*)password, (int)password_len,
                           salt, (int)salt_len, iterations,
                           EVP_sha256(), (int)key_len, out_key)) {
        return -1;
    }
    return 0;
}

// AES-256-GCM decrypt - so if wrong password, wont leak garbage
int aes256gcm_decrypt(const unsigned char *key, const unsigned char *nonce, size_t nonce_len,
                      const unsigned char *ciphertext, size_t ciphertext_len,
                      unsigned char *out, size_t *out_len)
{
    int ret = -1;
    EVP_CIPHER_CTX *ctx = NULL;
    int len = 0;
    int plaintext_len = 0;

    if (ciphertext_len < 16) return -2; // Ciphertext shorter than 16-byte leads to rejection

    const size_t tag_len = 16;
    size_t ct_only_len = ciphertext_len - tag_len;
    const unsigned char *tag_ptr = ciphertext + ct_only_len;

    ctx = EVP_CIPHER_CTX_new();
    if (!ctx) goto cleanup;

    if (1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL)) goto cleanup;
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, nonce_len, NULL)) goto cleanup;
    if (1 != EVP_DecryptInit_ex(ctx, NULL, NULL, key, nonce)) goto cleanup;

    if (1 != EVP_DecryptUpdate(ctx, out, &len, ciphertext, (int)ct_only_len)) goto cleanup;
    plaintext_len = len;

    // Check authentication so the decrypted data must match
    if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, (int)tag_len, (void*)tag_ptr)) goto cleanup;

    if (1 != EVP_DecryptFinal_ex(ctx, out + len, &len)) {
        // If authentication failed
        ret = -3;
        goto cleanup;
    }
    plaintext_len += len;
    *out_len = plaintext_len;
    ret = 0;

cleanup:
    if (ctx) EVP_CIPHER_CTX_free(ctx);
    return ret;
}

// Main
int main(void)
{
    ERR_load_crypto_strings();
    OpenSSL_add_all_algorithms();
    touch_password_fragments();

    size_t blob_len = encrypted_blob_len;
    const unsigned char *salt, *nonce, *ciphertext;
    size_t salt_len, nonce_len, ciphertext_len;

    if (parse_blob(encrypted_blob, blob_len, &salt, &salt_len, &nonce, &nonce_len, &ciphertext, &ciphertext_len) != 0) {
        fprintf(stderr, "bad embedded blob\n");
        return 1;
    }

    // Prompt user for password
    char input[256];
    printf("Enter a password to grab your gift from Santa's sack: ");
    if (!fgets(input, sizeof(input), stdin)) { return 1; }
    input[strcspn(input, "\r\n")] = 0;

    // Try to derive key from provided password
    unsigned char key[32];
    if (derive_key_pbkdf2((unsigned char*)input, strlen(input), salt, salt_len, ITERATIONS, key, sizeof(key)) != 0) {
        fprintf(stderr, "KDF failed\n");
        return 1;
    }

    // Decrypt
    unsigned char plaintext[1024];
    size_t plaintext_len = 0;
    int rc = aes256gcm_decrypt(key, nonce, nonce_len, ciphertext, ciphertext_len, plaintext, &plaintext_len);

    if (rc == 0) {
        // If correct password
        printf("Hooray! You got something that wasn't coal!:\n");
        fwrite(plaintext, 1, plaintext_len, stdout);
        printf("\n");
        return 0;
    } else {
        // If wrong password, return a random fake hex string (decodes to "coal")
        srand((unsigned int)time(NULL) ^ (unsigned int)getpid());
        int idx = rand() % 50;
        printf("You picked up something black and it stains, what might this be? :\n%s\n", fake_hex[idx]);
        printf("\nWhy don't you try to decode it.\n");
        return 1;
    }
}
